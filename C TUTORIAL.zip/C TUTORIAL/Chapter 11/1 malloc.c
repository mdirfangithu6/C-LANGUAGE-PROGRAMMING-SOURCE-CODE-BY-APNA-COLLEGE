// 10:07:45+ or 10:09:52+ par code

#include <stdio.h>

int main(){
    printf("%d\n", sizeof(int));
    printf("%d\n", sizeof(float));
    printf("%d\n", sizeof(char));
    return 0;
}
// output
// 4
// 4
// 1


// 10:11:46+ par code
#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr;
    ptr = (int *) malloc(5 * sizeof(int));

    ptr[0] = 1;
    ptr[1] = 3;
    ptr[2] = 5;
    ptr[3] = 7;
    ptr[4] = 9;

    for(int i=0; i<5; i++) {
    printf("%d\n", ptr[i]);
    }
    return 0;
}
// output
// 1
// 3
// 5
// 7
// 9