// 10:14:14+ par code
// Practice Qs 65
// WAP toallocate memory to store 5 prices.

#include <stdio.h>
#include <stdlib.h>

int main() {
    float *ptr;
    ptr = (float *) malloc(5 * sizeof(float));

    ptr[0] = 1;
    ptr[1] = 3;
    ptr[2] = 5;
    ptr[3] = 7;    I
    ptr[4] = 9;

    for(int i=0; i<5; i++) {
        printf("%d\n", ptr[i]);
    }
    return 0;
}
// output
// 1.000000
// 3.000000
// 5.000000
// 7.000000
// 9.000000
