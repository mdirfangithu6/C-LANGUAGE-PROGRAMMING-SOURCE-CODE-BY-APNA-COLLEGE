// 10:15:21+ or 10:16:51+ par code

#include <stdio.h>
#include <stdlib.h>

int main() {
    float *ptr;
    ptr = (float *) calloc(5, sizeof(float));

    // ptr[0] = 1;
    // ptr[1] = 3;
    // ptr[2] = 5;
    // ptr[3] = 7;    I
    // ptr[4] = 9;

    for(int i=0; i<5; i++) {
        printf("%d\n", ptr[i]);
    }
    return 0;
}
// output
// 0.000000
// 0.000000
// 0.000000
// 0.000000
// 0.000000

// 10:17:21+ par code
#include <stdio.h>
#include <stdlib.h>

int main() {
    float *ptr;
    ptr = (float *) malloc(5 * sizeof(float));

    // ptr[0] = 1;
    // ptr[1] = 3;
    // ptr[2] = 5;
    // ptr[3] = 7;    I
    // ptr[4] = 9;

    for(int i=0; i<5; i++) {
        printf("%d\n", ptr[i]);
    }
    return 0;
}
// output
// 0.000000
// 0.000000
// 0.000000
// 0.000000
// 0.000000