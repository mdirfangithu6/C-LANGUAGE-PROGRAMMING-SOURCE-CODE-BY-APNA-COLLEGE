// 10:22:00+ par code
// Practice Qs 67
// In Qs 67, free the memory allocated with calloc.