// 10:17:51+ par code
// Practice Qs 66
// WAP to allocate memory of size n, where n is entered by the user.

#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr;
    int n;
    printf("enter n : ");
    scanf("%d", &n);

    ptr = (int *) calloc(n, sizeof(int));

    for(int i=0; i<n; i++) {
        printf("%d\n", ptr[i]);
    }

    return 0;
}
// output
// enter n : 4
// 0
// 0
// 0
// 0