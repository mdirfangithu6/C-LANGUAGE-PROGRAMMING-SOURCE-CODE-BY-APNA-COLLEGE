// 10:22:18+
// realloc()



// 10:23:52+ 
// Practice Qs 68
// Allocate memory for 5 numbers. Then dynamically increase it to 8 numbers.
#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr;
    ptr = (int *) calloc(5, sizeof(int));

    printf("enter numbers(5) : ");
    for(int i=0; i<5; i++) {
        scanf("%d", &ptr[i]);
    }

    ptr = realloc(ptr, 8);
    printf("enter numbers(8) : ");
    for(int i=0; i<8; i++) {
        scanf("%d", &ptr[i]);
    }

//print
    for(int i=0; i<8; i++) {
        printf("number %d is %d", i, ptr[i]);
    }

    return 0;
}
// output
// enter numbers(5) : 5
// 4
// 3
// 2
// 1
// enter numbers(8) : 8
// 7
// 6
// 5
// 4
// 3
// 2
// 1
// number 0 is 8number 1 is 7number 2 is 6number 3 is 5number 4 is 4number 5 is 3number 6 is 2number 7 is 1




// 10:25:55+ par code
#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr;
    ptr = (int *) calloc(5, sizeof(int));

    printf("enter numbers(5) : ");
    for(int i=0; i<5; i++) {
        scanf("%d", &ptr[i]);
    }

    ptr = realloc(ptr, 8);
    printf("enter numbers(8) : ");
    for(int i=0; i<8; i++) {
        scanf("%d\n", &ptr[i]);
    }

//print
    for(int i=0; i<8; i++) {
        printf("number %d is %d", i, ptr[i]);
    }

    return 0;
}
// output
// enter numbers(5) : 5 4 3 2 1
// enter numbers(8) : 8 7 6 5 4 3 2 1
// number 0 is 8
// number 1 is 7
// number 2 is 6
// number 3 is 5
// number 4 is 4
// number 5 is 3
// number 6 is 2
// number 7 is 1
