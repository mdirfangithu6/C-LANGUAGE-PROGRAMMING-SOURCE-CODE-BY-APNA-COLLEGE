// 10:26:12+ par code
// Practice Qs 69
// Create an array of size 5(using calloc) & enter its values from the user.

#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr;
    ptr = (int *) calloc(5, sizeof(int));

    printf("enter numbers(5) : ");
    for(int i=0; i<5; i++) {
        scanf("%d", &ptr[i]);
    }

    //print
    for(int i=0; i<8; i++) {
        printf("number %d is %d\n", i, ptr[i]);
    }
    return 0;
}
// output
// enter number(5) : 1 3 5 7 9 
// number 0 is 1
// number 1 is 3 
// number 2 is 5
// number 3 is 7
// number 4 is 9