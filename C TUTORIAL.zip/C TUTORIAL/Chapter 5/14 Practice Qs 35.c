// 5:20:48+ par code
// Practice Qs 35
// Write a function to print the nth term of the fibonacci sequence.

// by chatGPT
#include <stdio.h>

// Function to find the nth Fibonacci term
int fibonacci(int n) {
    if (n <= 1)
        return n;
    else
        return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int n, result;

    printf("Enter the position (n): ");
    scanf("%d", &n);

    result = fibonacci(n);

    printf("The %dth term of the Fibonacci sequence is %d\n", n, result);

    return 0;
}



// ----------------------------------------
// pichale wale code jaisa code is sawal ka 
// ----------------------------------------

#include <stdio.h>

int fib(int n);

int main() {
    int n;
    printf("Enter the position (n): ");
    scanf("%d", &n);

    printf("The %dth term of the Fibonacci sequence is %d\n", n, fib(n));

    return 0;
}

int fib(int n) {
    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }

    int fibNm1 = fib(n - 1);  // (n-1)th term
    int fibNm2 = fib(n - 2);  // (n-2)th term
    int fibN = fibNm1 + fibNm2;  // nth term

    return fibN;
}
// output
// Enter the position (n): 6
// The 6th term of the Fibonacci sequence is 8