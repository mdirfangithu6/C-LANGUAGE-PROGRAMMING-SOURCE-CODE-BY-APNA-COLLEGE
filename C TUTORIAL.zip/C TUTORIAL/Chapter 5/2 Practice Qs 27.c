// 4:03:54+ par code
// Practice Qs 27
// Wrote 2 function - one to print "Hello" & second to print "good bye".

#include <stdio.h>
// declartion/ prtotype
void printHello();
void printGoodbye();
int main(){

    printHello(); // function call
    printGoodbye();
    printHello();
    return 0;
}

// function defination
void printhlo(){
    printf("Hello;\n");
}
void goodbye(){
    printf("Goodbye:\n");
}
// output
// Hello 
// Goodbye

// Hello 
// Goodbye
// Hello 


