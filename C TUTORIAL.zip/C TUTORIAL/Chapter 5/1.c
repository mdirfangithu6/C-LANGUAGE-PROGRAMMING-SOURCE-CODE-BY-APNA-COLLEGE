// 3:59:55+ par code
#include<stdio.h>
//declaration/prototype
void printHello();

int main() {
    printHello(); //function call
    return 0;
}

//function definition
void printHello() {
    printf("Hello!");
}
// output
// Hello!


// 4:01:55+ par code
#include<stdio.h>
//declaration/prototype
void printHello();

int main() {
    printHello(); //function call
    printHello();
    printHello();
    return 0;
}

//function definition
void printHello() {
    printf("Hello!");
}
// output
// Hello!
// Hello!
// Hello!


// 4:03:00+ par code
#include<stdio.h>
//declaration/prototype
void printHello();

int main() {
    printHello(); //function call
    printHello();
    printHello();
    return 0;
}

//function definition
void printHello() {
    printf("Hello!");
    printf("My name is irfan");
}
// output
// Hello!
// My name is irfan
// Hello!
// My name is irfan
// Hello!
// My name is irfan