// 4:55:57+ par code
// Practice Qs 31
// Factorial of n.

#include <stdio.h>

int fact(int n);

int main() {
    printf("factorial is : %d", fact(5));
    return 0;
}

int fact(int n) {
    if(n == 0) {
        return 1;
    }
    int factNm1 = fact(n-1);
    int factN = factNm1 * n;
    return factN;
}
// output
// factorial is : 120


// 5:02:35+ par code
#include <stdio.h>

int fact(int n);

int main() {
    printf("factorial is : %d", fact(5));
    return 0;
}

int fact(int n) {
    printf("calculate fact of n : %d\n", n);
    int factNm1 = fact(n-1);
    int factN = factNm1 * n;
    return factN;
}
// output
// crash