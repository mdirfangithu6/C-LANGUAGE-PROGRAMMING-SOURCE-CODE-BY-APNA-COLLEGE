// 4:16:03+ par code

#include <stdio.h>
int sum(int a, int b);

int main() {
    int a, b;
    printf("enter first number : ");
    scanf("%d", &a);
    printf("enter second number : ");
    scanf("%d", &b);

    int s = sum(a, b);
    printf("sum is %d : ", s);
    return 0;

}

int sum(int x, int y) {  //int sum(int a, int b) {
    return x + y; // return a + b;
}
// output
// enter first number : 5
// enter second number : 3
// sum is : 8


// 4:21:21+ par code

#include <stdio.h>

void printTable(int n);

int main() {
    int n;
    printf("enter number : ");
    scanf("%d", &n);

    printTable(n); //argument/ actual parameter

    return 0;
}
void printTable(int n){ // parameter/ formal parameter
    for(int i=1; i<=10; i++){
        printf("%d\n", i*n);
    }
}
// output
// enter number : 5
// 5
// 10
// .......
// 50
