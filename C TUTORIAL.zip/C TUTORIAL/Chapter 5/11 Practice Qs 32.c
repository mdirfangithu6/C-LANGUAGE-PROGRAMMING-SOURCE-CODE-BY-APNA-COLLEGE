// 5:04:08+ par code
// Practice Qs 32
// Write a function to convert celsium to fahrenheit.

#include <stdio.h>

float converttemp(float celcius);

int main(){

    float far = converttemp(0);
    printf("far : %f", far);

    return 0;
}
float converttemp(float celcius){
    float far = celcius * (9.0 / 5.0) + 32;
    return far;
}
// output
// far : 32.000000