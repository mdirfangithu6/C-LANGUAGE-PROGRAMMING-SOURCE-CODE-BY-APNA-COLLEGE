// 5:21:24+ 
// HOMEWORK SET
// a. Write a function to find sum of digits of a number.
// b. Write a function to find square root of a number.
// c. Write a function to print "Hot" or "Cold" depen' on the temperature user enters.
// d. Make your own pow function.




// a. Write a function to find sum of digits of a number.
// by chatGPT
#include <stdio.h>
#include <math.h>

int main() {
    int num, originalNum, remainder, result = 0, n = 0;

    printf("Enter a number: ");
    scanf("%d", &num);
    originalNum = num;

    while (originalNum != 0) {
        originalNum /= 10;
        n++;
    }

    originalNum = num;
    while (originalNum != 0) {
        remainder = originalNum % 10;
        result += pow(remainder, n);
        originalNum /= 10;
    }

    if (result == num)
        printf("%d is an Armstrong number.\n", num);
    else
        printf("%d is not an Armstrong number.\n", num);

    return 0;
}




// b. Write a function to find square root of a number.
// by chatGPT
#include <stdio.h>

int main() {
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (num >= 1)
        printf("%d is a natural number.\n", num);
    else
        printf("%d is not a natural number.\n", num);

    return 0;
}



// c. Write a function to print "Hot" or "Cold" depen' on the temperature user enters.
// by chatGPT
#include <stdio.h>

int main() {
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (num % 2 == 0)
        printf("%d is even.\n", num);
    else
        printf("%d is odd.\n", num);

    return 0;
}




// d. Make your own pow function.
#include <stdio.h>

int main() {
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (num > 0)
        printf("The number is positive.\n");
    else if (num < 0)
        printf("The number is negative.\n");
    else
        printf("The number is zero.\n");

    return 0;
}