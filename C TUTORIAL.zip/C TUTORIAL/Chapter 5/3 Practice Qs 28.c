// 4:06:50+ par code
// Practice Qs 28
// Write a function that prints Namaste if user is Indian & Bonjour if the user is French

#include <stdio.h>
void namaste(); // declartion/ prtotype
void bonjour();
int main(){
    printf("enter f for french & i for indian : \n");
    char ch;
    scanf("%c", &ch);

    if(ch == 'i'){
        namaste();
    }
    else{
        bonjour();
    }
    return 0;
}
// function defination
void printnamste(){
    printf("Namaste\n");
}
void printbonjour(){
    printf("Bonjour\n");
}
// output
// enter f for french & i for indian : i
// Namaste
// enter f for french & i for indian : f
// Bonjour


// ----------------------------
// is code ko aor acha banana  
// if (c == 'f' || c == 'F'){
//     printbonjour();
// }
// else(c == 'i' || c == 'I'){
//     printnamste();
// }
// ----------------------------




// 4:11:00+ par code
#include <stdio.h>
void printnamaste(); // declartion/ prtotype
void printbonjour();
int main(){
    printf("enter f for french & i for indian : \n");
    char ch;
    scanf("%c", &ch);

    namaste():

    return 0;
}
// function defination
void printnamste(){
    printf("Namaste\n");
    bonjour();
}
void printbonjour(){
    printf("Bonjour\n");
}
// output
// enter f for french & i for indian : f
// Namaste
// Bonjour

