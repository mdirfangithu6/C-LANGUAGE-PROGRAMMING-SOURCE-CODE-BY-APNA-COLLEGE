// 4:28:16+ par code

#include <stdio.h>

void calculatePrice(float value);

int main() {
    float value = 100.0;
    calculatePrice(value);
    return 0;
}

void calculatePrice(float value) {
    value = value + (0.18 * value);
    printf("final price is : %f", value);
}
// output
// final price is : 188.00000


// 4:30:16+ par code

#include <stdio.h>

void calculatePrice(float value);

int main() {
    float value = 100.0;
    calculatePrice(value);
    printf("value is : %f", value);
    return 0;
}

void calculatePrice(float value) {
    value = value + (0.18 * value);
    printf("final price is : %f \n", value);
}
// output
// final price is : 188.00000
// value is : 100
