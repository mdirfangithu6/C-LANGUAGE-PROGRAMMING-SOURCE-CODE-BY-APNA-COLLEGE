// 4:32:56+ par code
// Practice Qs 29
// Use library functions to calculate the square of a number given by user.

#include <stdio.h>
#include <math.h>

int square(int x);
int main(){
    int n = 4;

    printf("%f", pow(n, 2));
    return 0;
}
int square(int x){
    return pow(x, 2);
}
// output
// 16.000000

// ---------------------------------------------
// code asal me aisa hoga lekin video me nahi hai
// ----------------------------------------------