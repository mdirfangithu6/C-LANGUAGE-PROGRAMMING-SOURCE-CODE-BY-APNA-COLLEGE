// 2:05:20+ par code
#include <stdio.h>

int main(){
    int age;
    printf("enter age : ");
    scanf("%d", &age);

    if(age > 18){
        printf("adult \n");
        printf("they can vote \n");
        printf("they can drive \n");
    }
    else{
        printf("not adult \n");
    }
    return 0;
}
// enter age : 15
// not adlut

// enter age : 22
// adult
// they can vote
// they can drive

// 2:08:37+ par code
#include <stdio.h>

int main(){
    int age;
    printf("enter age : ");
    scanf("%d", &age);

    if(age > 18){
        printf("adult \n");
        printf("they can vote \n");
        printf("they can drive \n");
    }
    else{
        printf("not adult \n");
    }
    printf("thank you");
    return 0;
}
// enter age : 19
// adult
// they can vote
// they can drive
// thank you


// 2:09:33+ par code (special chiz)
#include <stdio.h>

int main(){
    int age;
    printf("enter age : ");
    scanf("%d", &age);

    if(age > 18)
        printf("adult \n");
    else
        printf("not adult \n");
    return 0;
}
// enter age : 23
// adult
