// 2:36:36+ par code
// Practice Qs 11

// Will this code : 
int x = 2;

    if(x=1) {
        printf("x is equal to 1");
    } else {
        printf("x is not equal to 1");
    }

// a. give error
// b. print "x is equal to 1"
// c. print "x is not equal to 1"

#include<stdio.h>

int main() {
    int x = 2;

    if(x=1) {
        printf("x is equal to 1");
    } else {
        printf("x is not equal to 1");
    }
    return 0;
}
// output 
// x is equal to 1


// 2:39:00+ par code
#include<stdio.h>

int main() {
    int x = 2;

    if(x=4) {
        printf("x is equal to 1\n");
        printf("%d", x);
    } else {
        printf("x is not equal to 1");
    }
    return 0;
}
outp4ut
// x is equal to 1
