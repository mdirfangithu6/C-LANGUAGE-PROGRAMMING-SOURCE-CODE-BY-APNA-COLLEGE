// 2:11:08+ or 2:13:24+ par code

#include <stdio.h>

int main() {
    int age;
    printf("enter age : ");
    scanf("%d", &age);

    if(age >= 18) {
        printf("adult \n");
    }
    else if(age > 13 && age < 18) {
        printf("teenager \n");
    }
    else {
        printf("child");
    }

    return 0;
}
// enter age : 5
// child

// enter age : 16
// teenager

// enter age : 22
// adlut