// 2:41:06+ par ode
// Practice Qs 12
// Write a Program to find if a character entered by user is upper case or not

#include <stdio.h>

int main() {
    char ch;
    printf("enter character : ");
    scanf("%c", &ch);

    if(ch >= 'A' && ch <= 'Z') {
        printf("upper case \n");
    }
    else if(ch >= 'a' && ch <= 'z') {
        printf("lower case\n");
    }
    else {
        printf("not english letter\n");
    }

    return 0;
}
// enter character : G
// upper case

// enter character : g
// lower case

// enter character : %
// not english letter