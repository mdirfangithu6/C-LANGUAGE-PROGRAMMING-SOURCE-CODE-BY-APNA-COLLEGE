// 2:45:15+ 

// HOMEWORK SET
// a. Write a program to check if a given number is Armstrong number or not.
// (Search what is Armstrong number)
// b. Write a program to check if the given number is a natural number.
// (Natural numbers start from 1)




// a. Write a program to check if a given number is Armstrong number or not.
// (Search what is Armstrong number)
// by chatGPT

#include <stdio.h>
#include <math.h>

int main() {
    int num, originalNum, remainder, result = 0, n = 0;

    printf("Enter a number: ");
    scanf("%d", &num);
    originalNum = num;

    // Count number of digits
    while (originalNum != 0) {
        originalNum /= 10;
        n++;
    }

    originalNum = num;
    while (originalNum != 0) {
        remainder = originalNum % 10;
        result += pow(remainder, n);
        originalNum /= 10;
    }

    if (result == num)
        printf("%d is an Armstrong number.\n", num);
    else
        printf("%d is not an Armstrong number.\n", num);

    return 0;
}




// b. Write a program to check if the given number is a natural number.
// (Natural numbers start from 1)
// by chatGPT
#include <stdio.h>

int main() {
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    if (num >= 1)
        printf("%d is a natural number.\n", num);
    else
        printf("%d is not a natural number.\n", num);

    return 0;
}