// 2:15:00+ or 2:16:56+ par code

#include <stdio.h>

int main() {
    int age;
    printf("enter age : ");
    scanf("%d", &age);

    age >= 18 ? printf("adlut \n") : printf("not adlut \n");

    return 0;
}
// enter age : 15
// not adlut