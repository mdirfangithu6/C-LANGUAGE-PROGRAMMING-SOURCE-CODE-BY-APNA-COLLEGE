// 2:29:50+
// Practice Qs 9
// Write a program to check if a student passed or failed.
// marks > 30 is PASS
// marks <= 30 is FAIL

#include<stdio.h>

int main() {
    int marks;
    printf("enter number(0-100) : ");
    scanf("%d", &marks);

    if(marks <= 30) {
        printf("FAIL \n");
    } else {
        printf("PASS \n");
    }

    return 0;
}
// enter number(0-100) : 55
// PASS

// enter number(0-100) : 105
// PASS


// 2:31:25+
#include <stdio.h>

int main() {
    int marks;
    printf("enter number(0-100) : ");
    scanf("%d", &marks);

    if(marks >= 0 && marks <= 30) {
        printf("FAIL \n");
    } else if (marks > 30 && marks <=100) {
        printf("PASS \n");
    } else{
        printf("wrong marks");
    }

    return 0;
}
// enter number(0-100) : 105
// wrong marks



// 2:32:25+ (ternery)
#include <stdio.h>

int main() {
    int marks;
    printf("enter number(0-100) : ");
    scanf("%d", &marks);

    marks <= 30 ? printf("FAIL \n") : prntf("PASS \n");

    return 0;
}
// enter number(0-100) : 23
// FAIL

// enter number(0-100) : 89
// PASS