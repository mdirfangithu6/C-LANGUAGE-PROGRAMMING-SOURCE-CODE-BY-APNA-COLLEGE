// 3:05:30+ par code
#include <stdio.h>

int main(){
    for(int i=1; ; i++){
        printf("Hello World\n");
    }
    return 0;
}