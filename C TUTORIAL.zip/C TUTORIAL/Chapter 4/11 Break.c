// 3:29:57+ or 3:30:35+ par code
#include <stdio.h>

int main() {
    for(int i=1; i<=5; i++) {
        if(i == 3) {
            break;
        }
        printf("%d\n", i);
    }

    printf("end");

    return 0;
}
// 1
// 2
// end