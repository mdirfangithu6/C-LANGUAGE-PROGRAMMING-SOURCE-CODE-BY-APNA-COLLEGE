// 3:47:40+ par code
// Practice Qs 22
// Print reverse of the table for a number n.

#include<stdio.h>
int main(){ 
    int n;
    printf("enter number : ");
    scanf("%d", &n);

    for (int i=10; i>=1; i--){
       printf("%d\n", n * i);
    }
    
    return 0;
}
// output
// enter number : 2
// 20
// 18
// 16
// 14
// 12
// 10
// 8
// 6
// 4
// 2