// 3:07:37+ or 3:10:14+ par code
#include <stdio.h>

int main(){
    int i=1;
    while (i<=5){
        printf("Hello World\n");
        i++;
    }
    return 0;
}
// output
// Hello World
// Hello World
// Hello World
// Hello World
// Hello World


