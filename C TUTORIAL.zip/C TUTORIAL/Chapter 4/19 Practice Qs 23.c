// 3:49:13+ par code
// Practice Qs 23
// Calculate the sum of all numbers between 5 and 50.
// /(including 5 & 50)

#include<stdio.h>
int main(){
    int sum = 0;
    for (int i=5; i<=50; i++){
        sum = sum + i; // sum +=i;
    }
    printf("sum is %d", sum);

    return 0;
}
// output
// sum is 1265