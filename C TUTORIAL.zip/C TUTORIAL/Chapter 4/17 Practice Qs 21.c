// 3:4247+ par code
// Practice Qs 21
// Print the factorial of a number n.

#include <stdio.h>
int main(){
    int n;
    printf("enter number : ");
    scanf("%d", &n);

    int fact = 1;
    for (int i=1; i<=n; i++){
        fact = fact * i;
    }
    printf("final factorial is %d", fact);

    return 0;
}
// output
// enter number : 3
// final factorial is 6