// 2:56:14+
// Practice Qs 13
// Qs. Print the Number from 0 to 10
// 0 1 2 3 4 5 6 7 8 9 10

#include <stdio.h>

int main(){
    for(int i=0; i<=10; i+1){ // for(int i=0; i<=10; i++){
        printf("%d\n", i);
    }
    return 0;
}


// 2:58:20+ ++i --i
#include <stdio.h>

int main(){
    // increament operator
    // ++i i++
    int i=1;
    printf("%d \n", i++); // use, then increase
    printf("%d \n", i);
    return 0;
}
// 1

// 1
// 2


// 3:00:10+ par code
#include <stdio.h>

int main(){
    // increament operator
    // ++i (pre increment)
    // i++ (post increment)

    int i=1;
    printf("%d \n", ++i); // increase, then use
    printf("%d \n", i);


    return 0;
}
// 2
// 2

































// 3:01:20+ 
#include <stdio.h>

int main(){
    // decrement operator
    // --i (pre decrement)
    // i-- (post decrement)

    int i=1;
    printf("%d \n", i--);
    printf("%d \n", i);
    return 0;
}
// 1
// 0


#include <stdio.h>

int main(){
    // decrement operator
    // --i (pre decrement)
    // i-- (post decrement)

    int i=1;
    printf("%d \n", --i); 
    printf("%d \n", i);
    return 0;
}
// 0
// 