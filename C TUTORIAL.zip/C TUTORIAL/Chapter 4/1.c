// 2:45:50+
#include <stdio.h>

int main(){
    printf("Hello World");
    printf("Hello World");
    printf("Hello World");
    printf("Hello World");
    printf("Hello World");
    return 0;
}

// 2:51:40+
#include <stdio.h>

int main(){
    for(int i=1; i<=5; i++){
        printf("Hello World \n");
    }
    return 0;
}

