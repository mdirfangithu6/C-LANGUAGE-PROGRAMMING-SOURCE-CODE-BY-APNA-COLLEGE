// 2:53:00+

#include <stdio.h>

int main(){
    for(int i=1; i<=100; i++){
        printf("%d\n", i);
    }
    return 0;
}

// 2:54:08+
#include <stdio.h>

int main(){
    // iterator; counter
    for(int i=10; i>=1; i-1){ // for(int i=10; i>=1; i--){
        printf("%d\n", i);
    }
    return 0;
}