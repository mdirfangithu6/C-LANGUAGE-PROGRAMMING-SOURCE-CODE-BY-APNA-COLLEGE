// 3:03:30+ par code
#include<stdio.h>

int main() {
    for(float i=1.0; i<=5.0; i++) {
        printf("%f \n", i);
    }
    return 0;
}
// 1.000000
// 2.000000
// 3.000000
// 4.000000
// 5.000000



// 3:04:10+ par code
#include<stdio.h>

int main() {
    for(char ch='a'; ch<='z'; ch++) {
        printf("%c \n", ch);
    }
    return 0;
}
// output
// a 
// b
// c
// d
// e
// f
// g
// h
// i
// j
// k
// l
// m
// n
// o
// p
// q
// r
// s
// t
// u
// v
// w
// x
// y
// z