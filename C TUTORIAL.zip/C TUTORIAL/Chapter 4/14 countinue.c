// 3:38:20+ or 3:38:47+ par code
#include <stdio.h>

int main(){
    for(int i=1; i<=5; i++){
    if(i == 3) {
    continue;
    }
    printf("%d \n", i);
    }
    return 0;
}
// output
// 1
// 2
// 4
// 5