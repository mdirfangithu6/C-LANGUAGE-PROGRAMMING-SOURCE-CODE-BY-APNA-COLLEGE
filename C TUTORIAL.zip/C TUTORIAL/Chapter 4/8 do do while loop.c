// 3:16:48+ [ar code
#include <stdio.h>

int main(){
    int i = 1;
    do {
        printf("%d\n", i);
        i++;
    } while(i<=5);

    return 0;
}
// output
// 1
// 2
// 3
// 4
// 5


// 3:17:47+ par code 
#include <stdio.h>

int main(){
    int i = 5;
    do {
        printf("%d\n", i);
        i--;
    } while(i>=1);

    return 0;
}
// output
// 5
// 4
// 3
// 2
// 1