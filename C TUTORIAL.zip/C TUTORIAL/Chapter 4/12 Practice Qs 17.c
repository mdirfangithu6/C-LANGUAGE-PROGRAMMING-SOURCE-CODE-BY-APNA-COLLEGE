// 3:32:35+ par code
// Practice Qs 17
// Keep taking numbers as input from user util user anters an odd number.

#include <stdio.h>
int main(){
    int n;
    do{
        printf("enter number : ");
        scanf("%d", &n);
        printf("%d\n", n);
        
        if (n % 2! == 0){
            break;
        }

    } while (1);
    printf("thank you");

    return 0;
}
// output
// enter number : 2
// 2

// enter number : 3
// 3
// thank you
