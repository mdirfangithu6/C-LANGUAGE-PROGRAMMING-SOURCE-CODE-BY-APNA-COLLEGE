// 3:10:55+
// Practice Qs 14
// print the number from 0 to n, if n is given by user
// n = 4

#include <stdio.h>
int main(){

    int j;
    printf("enter your number :");
    scanf("%d", &j);
    
    int i = 0;
    while (i<=j){
        printf("%d \n", i);
        i++;
    }
    return 0;
}
// // enter number : 7
// 1
// 2
// 3
// 4
// 5
// 6
// 7

// 3:13:30+ par code
#include <stdio.h>
int main(){

    int n;
    printf("enter your number :");
    scanf("%d", &n);
    
    int i = 0;
    while (i<=n){
        printf("%d \n", i);
        i++;
    }

    for (int i = 0; i <=n; i++){
    printf("%d \n", i);
    }
    return 0;
}
// // enter number : 6
// 1
// 2
// 3
// 4
// 5
// 6