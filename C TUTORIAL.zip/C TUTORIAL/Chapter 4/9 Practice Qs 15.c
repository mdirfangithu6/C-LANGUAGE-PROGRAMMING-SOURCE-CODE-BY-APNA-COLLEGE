// 3:18:08+ par code
// Practice QS 15
// Print the Sum of First n Natural Numbers.
// n = 4 

// Also, print them in reverse

#include <stdio.h>
int main(){
    int n;
    printf("enter number : ");
    scanf("%d", &n);
    int sum = 0;

    for(int i=1; i<=n; i++){
        sum = sum + i; // sum += i
    }
    printf("sum is %d", sum);

    return 0;
}
// output
// enter number : 3
// sum is 6

// enter number : 5
// sum is 15


// 3:22:25+
// Also, print them in reverse
#include <stdio.h>
int main(){
    int n;
    printf("enter number : ");
    scanf("%d", &n);
    int sum = 0;

    for(int i=1; i<=n; i++){
        sum = sum + i; // sum += i
    }
    printf("sum is %d", sum);

    for(int i=n; i>=0; i--){
        printf("%d\n", i);
    }

    return 0;
}
// enter number : 3
// sum is 6
// 3
// 2
// 1


// // 3:24:18+ par code
// single for loop se
#include <stdio.h>
int main(){
    int n;
    printf("enter number : ");
    scanf("%d", &n);
    int sum = 0;

    for(int i=1; j=n; i<=n; && j>=1; i--, j--){
        sum = sum + i; // sum += i
    }
    printf("sum is %d", sum);

    return 0;
}
// output
// enter number : 3
// 3
// 2
// 1
// sum is 6



// 3:26:10+
// i ko hata sakte hai wala code
#include <stdio.h>
int main(){
    int n;
    printf("enter number : ");
    scanf("%d", &n);
    int sum = 0;

    for(int j=n; j>=1; j--){
        sum = sum + i; // sum += i
    }
    printf("sum is %d", sum);

    return 0;
}
// output
// enter number : 3
// 3
// 2
// 1
// sum is 6