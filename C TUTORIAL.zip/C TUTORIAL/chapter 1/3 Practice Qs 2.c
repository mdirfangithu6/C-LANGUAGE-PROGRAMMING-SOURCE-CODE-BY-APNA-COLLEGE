// 49:43+ par code
// Practice Qs 2
// 1. Write a program to calculate area of a circle.
// (radius is given)

#include<stdio.h>

//area of square
int main() {
    float radius;
    printf("enter radius");
    scanf("%f", &radius);

    printf("area is : %f", 3.14 * radius * radius);
    return 0;
}
// output
// enter radius3
// area is : 28.260000



