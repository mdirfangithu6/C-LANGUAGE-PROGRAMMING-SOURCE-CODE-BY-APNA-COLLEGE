// 48:14+
// Practice Qs 1
// 1. Write a program to calculate area of a square.
// (side is given)

#include<stdio.h>
//area of square
int main() {
    int side;
    printf("enter side");
    scanf("%d", &side);
    printf("area is : %d", side * side);
    return 0;
}
// enter side4
// area is : 16

// 49:00+ par code
#include<stdio.h>
//area of square
int main() {
    float side;
    printf("enter side");
    scanf("%f", &side);
    printf("area is : %f", side * side);
    return 0;
}
// enter side4
// area is : 16.0000
