#include <stdio.h>
int main(){
    printf("hello world");
    return 0;
}


// 16:34+ par code
#include <stdio.h>
int main(){
    
    int number = 25;
    char star = '*';
    int age = 22;
    float pi = 3.14;
    return 0;
}

// 18:23+ par code
#include <stdio.h>
int main(){
    
    int number = 25;
    char star = '*';
    int age = 22;
    float pi = 3.14;


    int a = 30;
    int A = 40;

    int _age = 22;
    
    int final_price = 100;

    return 0;
}



// 20:30+ par code
#include <stdio.h>
int main(){
    
    int number = 25;
    char star = '*';
    int age = 22;
    age = 24;
    float pi = 3.14;


    int a = 30;
    int A = 40;

    int _age = 22;
    
    int final_price = 100;

    return 0;
}


// 23:35+ par code
#include<stdio.h>
int main() {
    int age = 22;
    float pi = 3.14;
    char percentage = '#';
    return 0;
}


// 32:36+ par code
#include<stdio.h>

// this code display how data types work in C

/*
 
    This is a multi-line comment

*/

int main() {
    int age = 22;
    float pi = 3.14;
    char percentage = '#';
    return 0;
}


// 34:40+ par code
#include <stdio.h>
int main(){
    printf("hello C \n");
    printf("hello C \n");
    printf("hello C \n");
    printf("hello C \n");
    printf("hello C \n");
    return 0;
}
// output
// hello c
// hello c
// hello c
// hello c
// hello c



// 36:14+ par code
#include<stdio.h>
int main() {
    int age = 22;
    printf("age is %d", age);
    return 0;
}
// output
// age is 22


// 38:42+
#include<stdio.h>
int main(){
    float pi = 3.14;
    printf("%f, pi");
}
// output
// 3.140000


// 39:25+ par code
#include <stdio.h>
int main(){
    char star = '*';
    printf("star is %c, star");
}
// output
// star is *



// 41:14+ input 
#include<stdio.h>
int main() {
    int age;
    printf("enter age");
    scanf("%d", &age);
    printf("age is : %d", age);
    return 0;
}
// output
// enter age22
// age is : 22


// 42:30+ sum
#include <stdio.h>

int main() {
    int a, b;
    printf("enter a");
    scanf("%d", &a);

    printf("enter b");
    scanf("%d", &b);

    int sum = a + b;
    printf("sum is : %d", sum);
    return 0;
}
// output
// enter a2
// enter b5
// sum is : 7


// 44:30+ choti si trick
#include <stdio.h>

int main() {
    int a, b;
    printf("enter a");
    scanf("%d", &a);

    printf("enter b");
    scanf("%d", &b);

    printf("sum is : %d", a+b);
    return 0;
}
// output
// enter a2
// enter b5
// sum is : 7
