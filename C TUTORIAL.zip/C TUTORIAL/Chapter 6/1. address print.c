// 5:29:08+ par code

#include <stdio.h>

int main(){
    int age = 22;
    int *ptr = &age;
    int _age = *ptr;

    printf("%d", _age);
    return 0;
}
// output
// 22


// 5:34:21+ par code
#include <stdio.h>

int main(){
    int age = 22;
    int *ptr = &age;

    // address
    printf("%p", &age);
    printf("%u", &age);
    return 0;
}
// output
// kjdharskg8

// 2nd output
// kjdharskg8
// 8967535212


// 5:35:55+ par code
#include <stdio.h>

int main(){
    int age = 22;
    int *ptr = &age;

    // address
    // printf("%p", &age);
    printf("%u", &age);

    printf("%u", ptr);
    printf("%u", &ptr);

    return 0;
}
// output
// 7565425760
// 7565425760

// 2nd output
// 7565425760
// 7565425760
// 7565425752