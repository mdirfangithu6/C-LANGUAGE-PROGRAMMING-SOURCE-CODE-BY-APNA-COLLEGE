// 6:10:03+ par code
// Practice Qs 39
// Will the address output be same?


// call by reference
#include <stdio.h>

void printAddress(int n); 

int main() {
    int n = 4;
    printAddress(n); 
    printf("address of n is : %u\n", &n);  
    return 0;
}  

void printAddress(int n) {  
    printf("address of n is : %u\n", &n);  
}
// output
// address of n is : 0x7ffd4d3438fc  
// address of n is : 0x7ffd4d343920 



//call by value
// 6:13:05+ par code
#include <stdio.h>

void printAddress(int *n); 

int main() {
    int n = 4;
    printAddress(&n); 
    printf("address of n is : %u\n", &n);  
    return 0;
}  

void printAddress(int *n) {  
    printf("address of n is : %u\n", n);  
}
// output
// address of n is : 0x7ffd4d343820  
// address of n is : 0x7ffd4d343820