// 5:38:55+
#include <stdio.h>

int main(){
    int age = 22;
    int *ptr = &age;

    // value
    printf("%d", age);
    printf("%d", *ptr);
    printf("%d", *(&age));
    return 0;
}
// output
// 22

// 2nd output 
// 22
// 22
// 22