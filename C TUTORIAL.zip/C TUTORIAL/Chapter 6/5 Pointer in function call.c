// 5:54:36+ par code
#include <stdio.h>

void square(int n);

int main() {
    int number = 4;
    square(number);
    printf("number = %d\n", number);
    return 0;
}
// call by value
void square(int n) {
    n = n * n;
    printf("square = %d\n", n);
}
// output
// sqaure = 16
// number = 4



// 5:58:04+ par code
#include <stdio.h>


void _sqaure(int* n);

int main() {
    int number = 4;
    square(number);
    printf("number = %d\n", number);

    _sqaure(&number);
    printf("number = %d\n", number);
    return 0;
}
// call by reference
void _sqaure(int* n){
    *n = (*n) * (*n); // 4 * 4
    printf("square = %d\n", *n);
}
// output
// 16
// 16