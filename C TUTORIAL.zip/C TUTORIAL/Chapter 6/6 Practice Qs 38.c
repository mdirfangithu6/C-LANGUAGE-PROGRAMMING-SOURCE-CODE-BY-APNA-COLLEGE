// 6:02:25+ par code
// Practice Qs 38
// Swap 2 number, a & b.

#include <stdio.h>

void swap(int a, int b);

int main() {
    int x = 3, y = 5;
    swap(x, y);
    printf("x = %d & y = %d\n", x, y);
    return 0;
}

//call by value
void swap(int a, int b) {
    int t = a;
    a = b;
    b = t;
    printf("a = %d & b = %d\n", a, b);
}
// output
// a = 5 & b = 5
// x = 3 & y = 5


// 6:07:40+ par code
#include <stdio.h>

void _swap(int *a, int *b);

int main(){
    int x = 3 , y = 5 ;
    _swap(&x, &y);
    printf("x = %d & y = %d\n", x, y);
    return 0;
}

// call by reference
void _swap(int *a, int *b){
    int t = *a;
    *a = *b;
    *b = t;
}
// output
// x = 5 & y = 3