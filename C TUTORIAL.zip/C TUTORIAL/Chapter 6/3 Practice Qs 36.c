// 5:40:18+ par code
// Practice Qs 36
// Find output

#include <stdio.h>

int main() {
    int *ptr;
    int x;

    ptr = &x;
    *ptr = 0; // x = 0

    printf("x = %d\n", x); // 0
    printf("*ptr = %d\n", *ptr); // 0

    *ptr += 5; //x = 5
    printf("x = %d\n", x); // 5
    printf("*ptr = %d\n", *ptr); // 5

    (*ptr)++;
    printf("x = %d\n", x); // 6
    printf("*ptr = %d\n", *ptr); // 6

    return 0;
}
// output
// x = 0
// *ptr = 0

// 2nd output
// x = 0
// *ptr = 0
// x = 5
// Ptr = 5

// 3rd output
// x = 0
// *ptr = 0
// x = 5
// Ptr = 5
// x = 6
// *ptr = 6