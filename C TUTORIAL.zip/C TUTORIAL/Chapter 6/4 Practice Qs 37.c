// 5:49:58+ par code
// Practice Qs 37
// Print the value 'i' from its pointer to pointer

// 5:49:16+ par code
#include <stdio.h>

int main(){
    // float price = 100.00
    // float *ptr = &price;
    // float **pptr = &ptr;

    int i = 5;
    int *ptr = &i;
    int **pptr = &ptr;

    printf("%d\n", **pptr);

    return 0;
}
// output
// 5