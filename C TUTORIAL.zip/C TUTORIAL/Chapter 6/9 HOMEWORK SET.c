// 6:18:34+
// HOMEWORK SET
// a. Write a program in C to find the maximum number between two numbers using a pointer.
// b. Write a program in C to print the elements of an array in reverse order.
// c. Write a program in C to print all the letters in english alphabet using a pointer.



// a. Write a program in C to find the maximum number between two numbers using a pointer.
// by chatGPT
#include <stdio.h>

int main() {
    int a, b;
    int *p1, *p2;

    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    p1 = &a;
    p2 = &b;

    if (*p1 > *p2)
        printf("Maximum number is: %d\n", *p1);
    else
        printf("Maximum number is: %d\n", *p2);

    return 0;
}




// b. Write a program in C to print the elements of an array in reverse order.
// by chatGPT
#include <stdio.h>

int main() {
    int arr[100], n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Array in reverse order:\n");
    for (int i = n - 1; i >= 0; i--) {
        printf("%d ", arr[i]);
    }

    return 0;
}





// c. Write a program in C to print all the letters in english alphabet using a pointer.
// by chatGPT
#include <stdio.h>

int main() {
    char alphabet = 'A';
    char *ptr = &alphabet;

    printf("Uppercase Alphabets:\n");
    for (int i = 0; i < 26; i++) {
        printf("%c ", *ptr + i);
    }

    printf("\n\nLowercase Alphabets:\n");
    *ptr = 'a';
    for (int i = 0; i < 26; i++) {
        printf("%c ", *ptr + i);
    }

    return 0;
}