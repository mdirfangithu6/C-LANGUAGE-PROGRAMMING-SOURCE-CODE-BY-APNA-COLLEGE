// 9:41:05+ or 9:42:49+ par code

#include <stdio.h>

int main(){
    FILE *fptr;
    fptr = fopen("NewTest.txt", "w");

    char ch;
    fscanf(fptr, "%c", &ch);
    printf("character = %c", ch);

    fclose(fptr);
    return 0;
}
// output
// character = 


// 9:43:33+ par code
#include <stdio.h>

int main(){
    FILE *fptr;
    fptr = fopen("Test.txt", "r");

    char ch;
    fscanf(fptr, "%c", &ch);
    printf("character = %c\n", ch);

    fclose(fptr);
    return 0;
}
// output
// character = A


// 9:44:10+ par code
#include <stdio.h>

int main(){
    FILE *fptr;
    fptr = fopen("Test.txt", "r");

    char ch;
    fscanf(fptr, "%c", &ch);
    printf("character = %c\n", ch);
    fscanf(fptr, "%c", &ch);
    printf("character = %c\n", ch);
    fscanf(fptr, "%c", &ch);
    printf("character = %c\n", ch);
    fscanf(fptr, "%c", &ch);
    printf("character = %c\n", ch);
    fscanf(fptr, "%c", &ch);
    printf("character = %c\n", ch);
    

    fclose(fptr);
    return 0;
}
// output
// character = A
// character = p
// character = p
// character = l
// character = e






// 9:44:50+ par code
#include <stdio.h>

int main(){
    FILE *fptr;
    fptr = fopen("Test.txt", "r");

    int ch;
    fscanf(fptr, "%d", &ch);
    printf("character = %d\n", ch);
    fscanf(fptr, "%d", &ch);
    printf("character = %d\n", ch);
    fscanf(fptr, "%d", &ch);
    printf("character = %d\n", ch);

    fclose(fptr);
    return 0;
}
// output
// character = 123
// character = 456
// character = 898
