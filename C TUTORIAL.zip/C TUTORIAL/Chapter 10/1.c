// 9:33:55+ par code
// opening File

#include <stdio.h>

int main(){
    FILE *fptr;
    fptr = fopen("Test.txt", "r");
    return 0;
}



// 9:35:28+ or 9:36:36+ par code 
// Closing File

#include <stdio.h>

int main(){
    FILE *fptr;
    fptr = fopen("Test.txt", "r");
    fclose(fptr);
    return 0;
}
