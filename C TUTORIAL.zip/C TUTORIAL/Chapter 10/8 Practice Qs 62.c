// 9:56:28+ par code
// Practice Qs 62
// Make a program input student information from a user & enter it to a file.

#include <stdio.h>

int main() {
    FILE *fptr;
    fptr = fopen("Student.txt", "w");
    char name[100];
    int age;
    float cgpa;

    printf("enter name : ");
    scanf("%s", name);
    printf("enter age : ");
    scanf("%d", &age);
    printf("enter cgpa : ");
    scanf("%f", &cgpa);

    fprintf(fptr, "%s\t", name);
    fprintf(fptr, "%d\t", age);
    fprintf(fptr, "%f", cgpa);

    fclose(fptr);
    return 0;
}

// 9:59:20+ par code
#include <stdio.h>

int main() {
    FILE *fptr;
    fptr = fopen("Student.txt", "w");
    char name[100];
    int age;
    float cgpa;

    printf("enter name : ");
    scanf("%s", name);
    printf("enter age : ");
    scanf("%d", &age);
    printf("enter cgpa : ");
    scanf("%f", &cgpa);

    fprintf(fptr, "student name : %s\n", name);
    fprintf(fptr, "student age : %d\n", age);
    fprintf(fptr, "student cgpa : %f", cgpa);

    fclose(fptr);
    return 0;
}