// 10:04:27+ 
// HOMEWORK SET
// a. Write a program to read a string from a file & output to the user.
// b. Replace the data in file of Q(a) with the number of vowels in the string.
// c. Format the information of 5 students (name, marks, cgpa, course) in a table like structure in a file.


// a. Write a program to read a string from a file & output to the user.
// by chatGPT
#include <stdio.h>

int main() {
    FILE *file;
    char str[100];

    file = fopen("data.txt", "r");

    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    fgets(str, sizeof(str), file);
    printf("Data read from file: %s\n", str);

    fclose(file);
    return 0;
}

// > Note: Make sure a file named data.txt exists in the same folder with some text in it.




// b. Replace the data in file of Q(a) with the number of vowels in the string.
// by chatGPT
#include <stdio.h>
#include <ctype.h>

int main() {
    FILE *file;
    char str[100];
    int vowels = 0;

    file = fopen("data.txt", "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return 1;
    }

    fgets(str, sizeof(str), file);
    fclose(file);

    for (int i = 0; str[i] != '\0'; i++) {
        char ch = tolower(str[i]);
        if (ch == 'a'  ch == 'e'  ch == 'i'  ch == 'o'  ch == 'u')
            vowels++;
    }

    file = fopen("data.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return 1;
    }

    fprintf(file, "Number of vowels: %d\n", vowels);
    fclose(file);

    printf("Replaced file content with vowel count.\n");
    return 0;
}


// c. Format the information of 5 students (name, marks, cgpa, course) in a table like structure in a file.
// by chatGPT
#include <stdio.h>

struct Student {
    char name[50];
    int marks;
    float cgpa;
    char course[30];
};

int main() {
    FILE *file;
    struct Student students[5];

    // Input
    for (int i = 0; i < 5; i++) {
        printf("Enter info for Student %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", students[i].name);
        printf("Marks: ");
        scanf("%d", &students[i].marks);
        printf("CGPA: ");
        scanf("%f", &students[i].cgpa);
        printf("Course: ");
        scanf("%s", students[i].course);
    }

    // Write to file
    file = fopen("students.txt", "w");
    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    fprintf(file, "%-15s %-10s %-10s %-15s\n", "Name", "Marks", "CGPA", "Course");
    fprintf(file, "-------------------------------------------------------\n");
    for (int i = 0; i < 5; i++) {
        fprintf(file, "%-15s %-10d %-10.2f %-15s\n",
                students[i].name, students[i].marks, students[i].cgpa, students[i].course);
    }

    fclose(file);
    printf("Student information written to 'students.txt'\n");

    return 0;
}