// 9:39:16+ par code

#include <stdio.h>

int main() {
    FILE *fptr;
    fptr = fopen("NewTest.txt", "r");
    if(fptr == NULL) {
        printf("file doesn't exist\n");
    } 
    else {

        fclose(fptr);
    }
    return 0;
}
// output
// file doesn't exist

