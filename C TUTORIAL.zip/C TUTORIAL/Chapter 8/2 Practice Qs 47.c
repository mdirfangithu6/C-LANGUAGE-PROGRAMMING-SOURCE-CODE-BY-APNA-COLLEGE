// 7:28:55+ par code
// Practice Qs 47
// Create a String firstNumber & lastName to store details user & print all the characters using a loop.

#include <stdio.h>
void printString(char arr[]);

int main() {
    char firstName[] = "Muhammad";
    char lastName[] = "Irfan";

    printString(firstName);
    printString(lastName);
    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0'; i++) {
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// Muhammad 
// Irfan