// 7:43:17+ or 7:45:08+ par code

#include <stdio.h>

void printString(char arr[]);

int main() {
    char *canChange = "Hello World";
    puts(canChange);
    canChange = "Hello";
    puts(canChange);


    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0', i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// Hello World
// Hello

// 7:45:50+ par code
#include <stdio.h>

void printString(char arr[]);

int main() {
    char *canChange = "Hello World";
    puts(canChange);
    canChange = "Hello";
    puts(canChange);

    char cannotChange[] = "Hello World";
    puts(canChange);
    canChange = "Hello";

    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0', i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}