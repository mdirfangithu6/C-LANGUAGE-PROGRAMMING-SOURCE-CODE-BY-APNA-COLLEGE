// 8:25:54+ 
// HOMEWORK SET
// a. Write a program to convert all lowercase vowels to uppercase in a string.
// b. Write a program to print the highest frequency character in a string.
// c. Write a program to remove blank spaces in a string.
// d. Write a program to replace lowercase letters with uppercase & vice versa in a string.




// a. Write a program to convert all lowercase vowels to uppercase in a string.
// by chatGPT
#include <stdio.h>

int main() {
    char str[100];
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == 'a') str[i] = 'A';
        else if (str[i] == 'e') str[i] = 'E';
        else if (str[i] == 'i') str[i] = 'I';
        else if (str[i] == 'o') str[i] = 'O';
        else if (str[i] == 'u') str[i] = 'U';
    }

    printf("Updated string: %s", str);
    return 0;
}


// b. Write a program to print the highest frequency character in a string.
// by chatGPT
#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int freq[256] = {0};
    char maxChar;
    int max = 0;

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; str[i] != '\0'; i++) {
        freq[(int)str[i]]++;
        if (str[i] != ' ' && freq[(int)str[i]] > max) {
            max = freq[(int)str[i]];
            maxChar = str[i];
        }
    }

    printf("Character with highest frequency: %c (occurs %d times)\n", maxChar, max);
    return 0;
}


// c. Write a program to remove blank spaces in a string.
// by chatGPT
#include <stdio.h>

int main() {
    char str[100], result[100];
    int j = 0;

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] != ' ')
            result[j++] = str[i];
    }

    result[j] = '\0';

    printf("String without spaces: %s", result);
    return 0;
}


// d. Write a program to replace lowercase letters with uppercase & vice versa in a string.
// by chatGPT
#include <stdio.h>
#include <ctype.h>

int main() {
    char str[100];

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; str[i] != '\0'; i++) {
        if (islower(str[i]))
            str[i] = toupper(str[i]);
        else if (isupper(str[i]))
            str[i] = tolower(str[i]);
    }

    printf("Toggled string: %s", str);
    return 0;
}





