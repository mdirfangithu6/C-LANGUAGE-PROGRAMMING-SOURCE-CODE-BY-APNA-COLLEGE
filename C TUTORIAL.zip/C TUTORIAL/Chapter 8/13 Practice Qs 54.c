// 8:22:40+
// Practice Qs 54
// Check if a given character is present in a string or not.

#include <stdio.h>
#include <string.h>

void checkChar(char str[], char ch);

int main(){
    char str[] = "ApnaCollege";
    char ch ='e'
    chechchar(str, ch);
}

void checkChar(char str[], char ch){
    for (int i=0; str[i]!='\0'; i++){
        if (str[i] == ch){
            printf("character is present!");
            return;
        }
    }
    printf("character is NOT present:(");
}
// output
// character is present