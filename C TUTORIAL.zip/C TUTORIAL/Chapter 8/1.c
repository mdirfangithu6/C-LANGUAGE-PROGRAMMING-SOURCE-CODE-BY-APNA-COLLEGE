// 7:24:55+ par code
#include <stdio.h>

int main(){
    char name[] = {'i','r','f','a','n'};
    return 0;
}

// 7:26:48+ par code
#include <stdio.h>

int main(){
    char name[] = "irfan";
    return 0;
}

// 7:27:24+ par code
#include <stdio.h>

int main(){
    char name = "irfan";
    char class[] = "apna college";
    return 0;
}
