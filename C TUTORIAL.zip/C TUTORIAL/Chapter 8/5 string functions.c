// 7:39:10+ 

#include <stdio.h>

void printString(char arr[]);

int main() {
    // char firstName[50];
    // scanf("%s", firstName);
    // printf("your name is %s", firstName);

    char str[100];
    gets(str);
    puts(str);

    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0', i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// hello world
// hello world

// 2nd output
// Muhammad Irfan is a good student
// Muhammad Irfan is a good student


// 7:41:33+
// fgets
#include <stdio.h>

void printString(char arr[]);

int main() {
    // char firstName[50];
    // scanf("%s", firstName);
    // printf("your name is %s", firstName);

    char str[100];
    fgets(str, 100, stdin);
    puts(str);

    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0', i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// Muhammad Irfan
// Muhammad Irfan
// 