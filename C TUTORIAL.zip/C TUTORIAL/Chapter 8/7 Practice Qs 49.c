// 7:46:33+ par code
// Practice Qs 49
// Make a program that inputs user's name & pointsits lenght.

#include <stdio.h>

void printfString(char arr[]);
int countLength(char arr[]);

int main(){
    char name[100];
    fgets(name, 100, stdin);
    printf("length is : %d", countLength(name));
    return 0;
}

int countLength(char arr[]){
    int count = 0;
    for(int i=0; arr[i]!='\0'; i++){
        count++;
    }
    return count-1;
}

void printString(char arr[]){
    for(int i=0; arr[i]!='0'; i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// irfan
// length is : 6

// 2nd output
// irfan
// length is : 5