// 7:51:22+ or 7:52:31+ par code

#include <stdio.h>
#include <string.h>

void printfString(char arr[]);
int countLength(char arr[]);

int main(){
    char name[] = "irfan";
    int length = strlen(name);
    printf("length is : %d", length);
    return 0;
}

int countLength(char arr[]){
    int count = 0;
    for(int i=0; arr[i]!='\0'; i++){
        count++;
    }
    return count-1;
}

void printString(char arr[]){
    for(int i=0; arr[i]!='0'; i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// length is : 5







// 7:53:36+ 2 strcpy 
#include <stdio.h>
#include <string.h>

// void printString(char arr[]);
// int countLength(char arr[]);

int main() {
    char oldStr[] = "oldStr";
    char newStr[] = "newStr";
    strcpy(newStr, oldStr);
    puts(newStr);
    return 0;
}
// output
// oldStr



// 7:55:17+ or 7:57:16+  3 strcat
#include <stdio.h>
#include <string.h>

// void printString(char arr[]);
// int countLength(char arr[]);

int main() {
    // char oldStr[] = "oldStr";
    // char newStr[] = "newStr";
    // strcpy(newStr, oldStr);
    // puts(newStr);

    char firstStr[100] = "Hello ";
    char secString[] = "World";
    strcat(firstStr, secString);
    puts(firstStr);
    return 0;
}
// output
// Hello World





// 7:58:53+ or 8:01:26+ 4 strcmp
#include <stdio.h>
#include <string.h>

//void printString(char arr[]);
// int countLength(char arr[]);

int main() {
    char firstStr[] = "Apple";
    char secStr[] = "Banana";
    printf("%d", strcmp(firstStr, firstStr)); //printf("%d", strcmp(secStr, firstStr));
}
// output
// -1

// 2nd output
// 1