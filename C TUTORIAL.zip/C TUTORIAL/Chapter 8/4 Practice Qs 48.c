// 7:37:00+ par code
// Practice Qs 48
// Ask the use rto enter their firstName & print it back to them.

// Also try this with their fullName

#include <stdio.h>

void printString(char arr[]);

int main() {
    char firstname[50];    I
    scanf("%s", firstname);
    printf("your name is %s", firstname);
    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0', i++){
    printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// Irfan
// your name is Irfan


// 7:37:37+ par code
#include <stdio.h>

void printString(char arr[]);

int main() {
    // char firstName[50];
    // scanf("%s", firstName);
    // printf("your name is %s", firstName);

    char fullName[100];
    scanf("%s", fullName);
    printf("your full name is : %s", fullName);

    return 0;
}

void printString(char arr[]) {
    for(int i=0; arr[i] != '\0', i++){
        printf("%c", arr[i]);
    }
    printf("\n");
}
// output
// Muhammad Irfan
// your full name is : Muhammad