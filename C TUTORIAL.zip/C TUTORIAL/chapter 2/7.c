// 1:46:08+
#include <stdio.h>

int main(){
    int a = 1;
    int b = 4;
    a = a + b; // a = a+b  ->  a+=b 
    printf("%d\n", a);
    return 0;
}
// 5