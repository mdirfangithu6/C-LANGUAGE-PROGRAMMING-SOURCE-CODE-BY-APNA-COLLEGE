// 1:14:34+
// Practice Qs 3
// Solve :
// int a = 1.999999;

#include <stdio.h>

int main(){
    int a = (int) 1.99999;
    printf("%d\n", a);
    return 0;
}