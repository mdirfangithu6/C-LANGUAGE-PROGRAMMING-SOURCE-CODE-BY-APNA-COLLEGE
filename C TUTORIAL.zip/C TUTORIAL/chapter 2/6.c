// 1:37:07+ par code
// &&
#include <stdio.h>

int main(){
    
    printf("%d\n", 4>3 && 5>2);
    return 0;
}
// 1

#include <stdio.h>

int main(){
    
    printf("%d\n", 3>4 && 5>2);
    return 0;
}
// 0



// 1:41:23+ par code
// ||
#include <stdio.h>

int main(){
    
    printf("%d\n", 3>4 || 5>2);
    return 0;
}
// 0



// 1:42:42+ par code
// !
#include <stdio.h>

int main(){
    
    printf("%d\n", !(5>1));
    return 0;
}
// 0


#include <stdio.h>

int main(){
    
    printf("%d\n", !((5>1) && (3>4)));
    return 0;
}
// 1