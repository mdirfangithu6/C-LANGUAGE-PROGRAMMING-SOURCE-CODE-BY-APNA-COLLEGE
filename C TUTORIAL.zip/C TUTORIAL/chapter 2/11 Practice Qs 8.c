// 1:56:26+
// Practice Qs 8
// Print 1(true) or O(false) for following statements :
// a. if it's sunday & it's snowing -> true
// b. if it's monday or it's raining -> true
// c. if a number is greater than 9 & less than 100 -> true
// (2 digit number)


// a. if it's sunday & it's snowing -> true
#include <stdio.h>

int main(){
    int isSunday = 1;
    int isSnowing = 1;
    printf("%d", isSunday && isSnowing);
    return 0;
}
// 1



// b. if it's monday or it's raining -> true
#include <stdio.h>

int main(){
    int isMonday = 0;
    int isRaining = 1;
    printf("%d", isMonday || isRaining);
    return 0;
}
// 1



// c. if a number is greater than 9 & less than 100 -> true
#include <stdio.h>

int main(){
    int x;
    printf("enter number : ");
    scanf("%d", &x);
    printf("%d\n", x>9 && x<100);
    return 0;
}
// enter number : 78
// 1
// enter number : 101
// 0







