// 01:48:14+
// Practice Qs 5
// a. Write a program to check if a number is divisible by 2 or not.

#include <stdio.h>

int main(){
    int x;
    printf("enter a number :");
    scanf("%d", &x);
    printf("%d", x % 2 == 0);
    return 0;
}
// enter a number : 5
// 0
// enter a number :10
// 1