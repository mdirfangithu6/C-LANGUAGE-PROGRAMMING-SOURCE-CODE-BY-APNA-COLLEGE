//2:00:54+
// HOMEWORK SET
// a. Write a program to print the average of 3 numbers.
// b. Write a program to check if given character is digit or not.
// c. Write a program to print the smallest number.

// by chatGPT
// a. Write a program to print the average of 3 numbers.
#include <stdio.h>

int main() {
    float num1, num2, num3, average;

    printf("Enter three numbers: ");
    scanf("%f %f %f", &num1, &num2, &num3);

    average = (num1 + num2 + num3) / 3;

    printf("Average = %.2f\n", average);

    return 0;
}


// b. Write a program to check if given character is digit or not.
#include <stdio.h>

int main() {
    char ch;

    printf("Enter a character: ");
    scanf(" %c", &ch); // Note the space before %c to consume any leftover newline

    if (ch >= '0' && ch <= '9') {
        printf("The character is a digit.\n");
    } else {
        printf("The character is not a digit.\n");
    }

    return 0;
}


// c. Write a program to print the smallest number.
#include <stdio.h>

int main() {
    int num1, num2, num3, smallest;

    printf("Enter three numbers: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    smallest = num1;

    if (num2 < smallest)
        smallest = num2;
    if (num3 < smallest)
        smallest = num3;

    printf("Smallest number is: %d\n", smallest);

    return 0;
}