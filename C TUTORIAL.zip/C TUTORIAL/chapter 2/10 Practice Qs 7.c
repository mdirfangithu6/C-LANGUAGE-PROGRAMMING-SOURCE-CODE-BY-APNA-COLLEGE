// 1:52:20+
// Practice Qs 7
// Are the following valid or not?
// a. int a = 8^8
// b. int x; int y = x;
// c. int x, y = x;
// d. char stars = '**';

// a. int a = 8^8
#include <stdio.h>

int main(){
    printf("%d", 8^8);
    return 0;
}
// 0
// valid


// b. int x; int y = x;
#include <stdio.h>

int main(){
    int x; int y = x;
    return 0;
}
// valid


// c. int x, y = x;
#include <stdio.h>

int main(){
    int x, int y = x;
    return 0;
}
// invalid



// d. char stars = '**';
#include <stdio.h>

int main(){
    char stars = '**';
    return 0;
}
// invalid