// 1:21:46+ par code

#include <stdio.h>

int main(){
    int a = 4 * 3 / 6 * 2;
    printf("%d\n", a);
    return 0;
}