// 1:22:29+ par code
// Practice Qs 4
// a. 5*2-2*3
// b. 5*2/2*3
// c. 5*(2/2)*3
// d. 5+2/2*3


// a. 5*2-2*3
#include <stdio.h>

int main (){
    int a = 5*2-2*3;
    printf("%d\n", a);
    return 0;
}

// b. 5*2/2*3
#include <stdio.h>

int main (){
    int a = 5*2/2*3;
    printf("%d\n", a);
    return 0;
}

// c. 5*(2/2)*3
#include <stdio.h>

int main (){
    int a = 5*(2/2)*3;
    printf("%d\n", a);
    return 0;
}


// d. 5+2/2*3
#include <stdio.h>

int main (){
    int a = 5+2/2*3;
    printf("%d\n", a);
    return 0;
}