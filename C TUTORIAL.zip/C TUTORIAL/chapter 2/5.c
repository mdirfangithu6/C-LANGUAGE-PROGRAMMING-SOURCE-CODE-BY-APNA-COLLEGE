// 1:31:56+
#include <stdio.h>

int main(){
    printf("%d\n", 4 == 4);
    return 0;
}
// 1

#include <stdio.h>

int main(){
    printf("%d\n", 4 == 3);
    return 0;
}
// 0



// 1:33:52+ par code
// Greaterthen >>=
#include <stdio.h>

int main(){
    printf("%d\n", 4>3);
    return 0;
}
//1

#include <stdio.h>

int main(){
    
    printf("%d\n", 3>4);
    return 0;
}
// 0



// 
// lessthen <,<=

#include <stdio.h>

int main(){
    
    printf("%d\n", 3<3);
    return 0;
}
// 1




// !=
#include <stdio.h>

int main(){
    
    printf("%d\n", 4!=4);
    printf("%d\n", 4 == 4);
    return 0;
}
// 0
// 1