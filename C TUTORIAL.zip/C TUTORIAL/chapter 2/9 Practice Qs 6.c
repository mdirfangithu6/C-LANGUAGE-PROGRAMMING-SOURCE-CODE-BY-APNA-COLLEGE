// 1:51:40+
// Practice Qs 6
// a. Write a program to check if a number is odd or even.

#include <stdio.h>

int main(){
    // even -> 1
    // odd  -> 0
    int x;
    printf("enter a number :");
    scanf("%d", &x);
    printf("%d", x % 2 == 0);
    return 0;
}
// enter a number : 16
// 1
// enter a number : 7
// 0
