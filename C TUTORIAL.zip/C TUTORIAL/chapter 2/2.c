// 1:19:41+

#include <stdio.h>

int main(){
    int a = 4 + 9 * 10;
    printf("%d\n", a);
    return 0;
}