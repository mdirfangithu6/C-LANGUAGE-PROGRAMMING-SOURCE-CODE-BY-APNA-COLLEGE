// 55:14+ par code

#include <stdio.h>

int main(){
    int a = 22;
    int b = a;
    int c = b*6;
    int d = 1, e;

    int oldAge = 22;
    int newAge = oldAge + years;
    int years = 2;

    int a,y,z;
    x = y = z = 4;

    return 0;
}


// 1:01:05+ par code
#include <stdio.h>
int main(){

    int a =1; b = 2;
    int sum = a + b; 
    int multiple = a * b;

    inr x, y = a * b;
    
    return 0;
}



// 1:04:02+ par code
#include <stdio.h>
#include <math.h>

int main (){
    int b, c;
    b = c = 1;
    int a = b + c;

    int d = bc;

    int power = pow(b,c); //b^c;
    printf("%d", power);
    return 0;
}


// 1:08:42+ par code
#include <stdio.h>

int main(){
    printf("%d", 16%10);
    return 0;
}

#include <stdio.h>

int main(){
    printf("%d", -8%3);
    return 0;
}


// 1:11:51+ par code
#include <stdio.h>

int main(){
    printf("%d", 2*2);
    return 0;
}

#include <stdio.h>

int main(){
    printf("%f", 2.0*2);
    return 0;
}




#include <stdio.h>

int main(){
    printf("%f", 4/2.0);
    return 0;
}





