// 9:17:47+ par code
// Practice Qs 59
// You have to store the marks of 30 students in class.
// What will you use?
// a. array of 10 floats
// b. structure


// anwser = a. array of 10 floats bana lo

#include <stdio.h>

int main() {
    float marks[10];  // 10 floats ka array

    // Input lena
    for(int i = 0; i < 10; i++) {
        printf("Student %d ke marks daalo: ", i + 1);
        scanf("%f", &marks[i]);
    }

    // Output dikhana
    printf("\nStudents ke marks:\n");
    for(int i = 0; i < 10; i++) {
        printf("Student %d: %.2f\n", i + 1, marks[i]);
    }

    return 0;
}
// output
// Student 1 ke marks daalo: 75.5
// Student 2 ke marks daalo: 80
// ...
// Student 10 ke marks daalo: 65.75

// Students ke marks:
// Student 1: 75.50
// Student 2: 80.00
// ...
// Student 10: 65.75