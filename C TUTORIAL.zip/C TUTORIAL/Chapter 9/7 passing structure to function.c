// 8:52:57+ or 8:53:59+ par code

#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

void printInfo(struct student s1);

int main() {
    struct student s1 = {1664, 9.2, "irfan"};
    printInfo(s1);
    // printf("student roll = %d\n", s1.roll);

    

    return 0;
}

void printInfo(struct student s1){
    printf("student infomation : \n");
    printf("student.roll = %d\n", s1.roll);
    printf("student.name = %d\n", s1.name);
    printf("student.cgpa = %d\n", s1.cgpa);
}
// output
// student infomation : 
// student.roll = 1664
// student.name = irfan
// student.cgpa = 58958496


// 8:56:00+ call by value ya call by reference
#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

void printInfo(struct student s1);

int main() {
    struct student s1 = {1664, 9.2, "irfan"};
    printInfo(s1);
    // printf("student roll = %d\n", s1.roll);
    printf("student.roll = %d\n", s1.roll);
    

    return 0;
}

void printInfo(struct student s1){
    printf("student infomation : \n");
    printf("student.roll = %d\n", s1.roll);
    printf("student.name = %d\n", s1.name);
    printf("student.cgpa = %d\n", s1.cgpa);

    s1.roll = 1660;
}
// output
// student infomation : 
// student.roll = 1664
// student.name = irfan
// student.cgpa = 215102112
// student.roll = 1664

// call by value hua hai 