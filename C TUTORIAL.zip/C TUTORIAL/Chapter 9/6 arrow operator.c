// 8:50:00+ or 8:51:16+ par code

#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

int main() {
    struct student s1 = {1664, 9.2, "irfan"};
    printf("student roll = %d\n", s1.roll);

    struct student *ptr = &s1;
    printf("student.roll with ptr = %d\n", (*ptr).roll);
    printf("student->roll = %d\n", ptr->roll);

    return 0;
}
// output
// student roll = 1664
// student.roll with ptr = 1664
// student->roll = 1664


// 8:51:54+ par code
#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

int main() {
    struct student s1 = {1664, 9.2, "irfan"};
    printf("student roll = %d\n", s1.roll);

    struct student *ptr = &s1;
    printf("student.roll with ptr = %d\n", (*ptr).roll);

    printf("student->roll = %d\n", ptr->roll);
    printf("student->name = %d\n", ptr->name);
    printf("student->cgpa = %d\n", ptr->cgpa);

    return 0;
}
// output
// student roll = 1664
// student.roll with ptr = 1664
// student->roll = 1664
// student->name = irfan
// student->cgpa = 553210528