// 8:44:42+ or 8:45:50+ par code

#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

int main() {
    struct student s1 = {1664, 9.2, "irfan"};
    printf("student roll = %d\n", s1.roll);
    return 0;
}
// output
// student roll = -720271016
