// 9:21:00+ 
// HOMEWORK SET
// Make a system that can store information of all students, teachers & staff of your college in the form of structures.
// You can also make this into a C Project with other functionalities like cgpa calculation of students, storing attendance etc.

// by chatGPT
#include <stdio.h>
#include <string.h>

// Structures
struct Student {
    char name[50];
    int rollNo;
    float marks[5];
    float cgpa;
    int attendance;
};

struct Teacher {
    char name[50];
    char subject[30];
    int employeeID;
};

struct Staff {
    char name[50];
    char position[30];
    int staffID;
};

// Function to calculate CGPA
float calculateCGPA(float marks[], int n) {
    float total = 0;
    for (int i = 0; i < n; i++)
        total += marks[i];
    return total / n / 10; // assuming marks out of 100
}

int main() {
    struct Student students[100];
    struct Teacher teachers[50];
    struct Staff staff[50];
    int studentCount = 0, teacherCount = 0, staffCount = 0;
    int choice;

    do {
        printf("\n--- College Info Management System ---\n");
        printf("1. Add Student\n");
        printf("2. Add Teacher\n");
        printf("3. Add Staff\n");
        printf("4. View All Students\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // clear newline

        switch (choice) {
        case 1:
            printf("Enter student name: ");
            fgets(students[studentCount].name, 50, stdin);
            strtok(students[studentCount].name, "\n"); // remove newline

            printf("Enter roll number: ");
            scanf("%d", &students[studentCount].rollNo);

            printf("Enter marks in 5 subjects:\n");
            for (int i = 0; i < 5; i++) {
                printf("Subject %d: ", i + 1);
                scanf("%f", &students[studentCount].marks[i]);
            }

            students[studentCount].cgpa = calculateCGPA(students[studentCount].marks, 5);

            printf("Enter attendance (in %%): ");
            scanf("%d", &students[studentCount].attendance);

            studentCount++;
            printf("Student added successfully.\n");
            break;

        case 2:
            printf("Enter teacher name: ");
            fgets(teachers[teacherCount].name, 50, stdin);
            strtok(teachers[teacherCount].name, "\n");

            printf("Enter subject: ");
            fgets(teachers[teacherCount].subject, 30, stdin);
            strtok(teachers[teacherCount].subject, "\n");

            printf("Enter employee ID: ");
            scanf("%d", &teachers[teacherCount].employeeID);

            teacherCount++;
            printf("Teacher added successfully.\n");
            break;

        case 3:
            printf("Enter staff name: ");
            fgets(staff[staffCount].name, 50, stdin);
            strtok(staff[staffCount].name, "\n");

            printf("Enter position: ");
            fgets(staff[staffCount].position, 30, stdin);
            strtok(staff[staffCount].position, "\n");

            printf("Enter staff ID: ");
            scanf("%d", &staff[staffCount].staffID);

            staffCount++;
            printf("Staff member added successfully.\n");
            break;

        case 4:
            printf("\n--- Students Info ---\n");
            for (int i = 0; i < studentCount; i++) {
                printf("Name: %s\n", students[i].name);
                printf("Roll No: %d\n", students[i].rollNo);
                printf("CGPA: %.2f\n", students[i].cgpa);
                printf("Attendance: %d%%\n\n", students[i].attendance);
            }
            break;

        case 5:
            printf("Exiting program.\n");
            break;

        default:
            printf("Invalid choice.\n");
        }
    } while (choice != 5);

    return 0;
}