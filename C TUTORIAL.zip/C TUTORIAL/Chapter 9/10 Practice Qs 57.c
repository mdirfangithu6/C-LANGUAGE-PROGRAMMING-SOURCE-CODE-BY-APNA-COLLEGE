// 9:08:32+ par code
// Practice Qs 57
// Create a structure to store vectors. Then make a function to return sum of 2 vectors.

#include <stdio.h>

struct Vector {
    int x;
    int y;
};

void calcSum(struct Vector v1, struct Vector v2, struct Vector *sum);

int main() {
    struct Vector v1 = {5, 10};
    struct Vector v2 = {3, 7};
    struct Vector sum;

    calcSum(v1, v2, &sum);

    printf("Sum of x is: %d\n", sum.x);
    printf("Sum of y is: %d\n", sum.y);

    return 0;
}

void calcSum(struct Vector v1, struct Vector v2, struct Vector *sum) {
    sum->x = v1.x + v2.x;
    sum->y = v1.y + v2.y;
}
// output
// Sum of x is: 8
// Sum of y is: 17
