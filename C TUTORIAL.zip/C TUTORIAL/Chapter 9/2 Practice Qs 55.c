// 8:36:33+ 
// Practice Qs 55
// write a program to store the data of 3 students.

#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

int main(){
    struct student s1;
    s1.roll = 1660;
    s1.cgpa = 8.7;
    //s1.name = "Irfan";
    strcpy(s1.name, "Irfan");

    printf("student name = %s\n", s1.name);
    printf("student roll no = %d\n", s1.roll);
    printf("student cgpa = %f\n", s1.cgpa);

    struct student s2;
    s2.roll = 1664;
    s2.cgpa = 9.2;
    strcpy(s1.name, "Amanat");

    printf("student name = %s\n", s2.name);
    printf("student roll no = %d\n", s2.roll);
    printf("student cgpa = %f\n", s2.cgpa);

    struct student s3;
    s3.roll = 1662;
    s3.cgpa = 7.5;
    strcpy(s1.name, "Adnan");

    printf("student name = %s\n", s3.name);
    printf("student roll no = %d\n", s3.roll);
    printf("student cgpa = %f\n", s3.cgpa);

    return 0;
}
// output
// student name = Irfan
// student roll no = 1660
// student cgpa = 8.700000
// student name = Amanat
// student roll no = 1664
// student cgpa = 9.200000
// student name = Adnan
// student roll no = 1662
// student cgpa = 7.500000
