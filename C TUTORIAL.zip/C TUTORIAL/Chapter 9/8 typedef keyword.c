// 8:56:46+ or 8:59:56+ par code

#include <stdio.h>
#include <string.h>

// user defined
struct student{
    int roll;
    float cgpa;
    char name[100];
} stu;

typedef struct computerengineeringstudent{
    int roll;
    float cgpa;
    char name[100];
} coe;

int main(){
    coe s1;
    s1.roll = 1664;
    s1.cgpa = 9.2;
    strcpy(s1.name, "irfan");

    printf("student name is %s\n", s1.name);

    return 0;
}
// output
// student name is irfan