// 9:18:43+ par code
// Practice Qs 60
// Make s structure to store Bank Account Information of a customer of ABC Bank. Also, make an alias for it.

#include <stdio.h>

typedef struct BankAccount {
    int accountNo;
    char name[100];
} acc;

int main() {
    acc acc1 = {123, "irfan"};
    acc acc2 = {124, "amanat"};
    acc acc3 = {125, "adnan"};
    
    printf("acc no = %d\n", acc1.accountNo);
    printf("name = %s\n", acc1.name);
    return 0;
}
// output
// acc no = 123
// name = irfan