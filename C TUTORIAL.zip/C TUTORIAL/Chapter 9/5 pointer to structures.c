// 8:47:05+ par code

#include <stdio.h>
#include <string.h>

//user defined
struct student {
    int roll;
    float cgpa;
    char name[100];
};

int main() {
    struct student s1 = {1664, 9.2, "irfan"};
    printf("student roll = %d\n", s1.roll);

    struct student *ptr = &s1;
    printf("student roll = %d\n", (*ptr).roll);

    return 0;
}
// output
// student roll = 1664
// student roll = 1664