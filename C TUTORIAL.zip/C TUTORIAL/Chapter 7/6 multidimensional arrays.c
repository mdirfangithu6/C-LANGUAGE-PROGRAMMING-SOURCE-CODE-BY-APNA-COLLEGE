// 6:52:45+ or 6:55:55+ par code
#include <stdio.h>

int main() {
    // 2 x 3 array
    int marks[2][3]; // Rows x Columns
    
    // First student's marks
    marks[0][0] = 90;
    marks[0][1] = 89;
    marks[0][2] = 78;

    // Second student's marks
    marks[1][0] = 90;
    marks[1][1] = 89;
    marks[1][2] = 78;

    // Printing one element
    printf("%d", marks[0][0]);

    return 0;
}
// output
// 90