// 7:11:52+ par code
// Practice Qs 45
// Write a program to store the first n fibonacci numbers.

#include <stdio.h>

int main() {
    int n;
    printf("enter n (n>2): ");
    scanf("%d", &n);

    int fib[n];
    fib[0] = 0;
    fib[1] = 1;

    for(int i=2; i<n; i++) { 
        fib[i] = fib[i-1] + fib[i-2]; // important
        printf("%d ", fib[i]);
    }

    printf("\n");
    return 0;
}
// output
// 1      2     3     5     8     13     21     34