// 6:36:23+ par code

#include <stdio.h>

int main() {
    int age = 22;
    int *ptr = &age;
    
    printf("ptr = %u\n", ptr);  // Changed %u to %p for pointer address
    ptr++;
    printf("ptr = %u\n", ptr);  // Changed %u to %p
    
    return 0;
}
// ptr = 76536676152
// ptr = 76536676156


// 6:37:17+ par code
// case 1
#include <stdio.h>

int main() {
    int age = 22;
    int *ptr = &age;
    
    printf("ptr = %u\n", ptr);
    ptr++;
    printf("ptr = %u\n", ptr);
    ptr--;
    printf("ptr = %u\n", ptr);
    
    return 0;
}
// output
// ptr = 1826961112
// ptr = 1826961116
// ptr = 1826961112

// case 2
// 6:38:14+ par code
#include <stdio.h>

int main() {
    float price = 100.00;
    floa *ptr = &price;
    
    printf("ptr = %u\n", ptr);
    ptr++;
    printf("ptr = %u\n", ptr);
    ptr--;
    printf("ptr = %u\n", ptr);
    
    return 0;
}
// output
// ptr = 1807922904
// ptr = 1807922908
// ptr = 1807922904


// case 3
// 6:39:26+ par code
#include <stdio.h>

int main() {
    char star ='*';
    char *ptr = &star;
    
    printf("ptr = %u\n", ptr);
    ptr++;
    printf("ptr = %u\n", ptr);
    ptr--;
    printf("ptr = %u\n", ptr);
    
    return 0;
}
// output
// ptr = 1827256027
// ptr = 1827256028
// ptr = 1827256027




// 6:40:06+ par code
#include <stdio.h>

int main() {
    int age = 22;
    int _age = 23;
    int *ptr = &age;
    int *_ptr = &_age;

    printf("difference = %u\n", ptr-_ptr);  // Fixed: ptr__ptr -> ptr - _ptr
    _ptr = &age;
    printf("comparison = %u\n", ptr == _ptr);  // Fixed: __ptr -> _ptr and %u -> %d
    return 0;
}
// output
// difference = 1 
// comparison = 1



// 6:41:45+ par code
#include <stdio.h>

int main() {
    int age = 22;
    int _age = 23;
    int *ptr = &age;
    int *_ptr = &_age;

    printf("%u, %u\ndifference = %u\n", ptr,_ptr, ptr-_ptr);  // Fixed: ptr__ptr -> ptr - _ptr
    _ptr = &age;
    printf("comparison = %u\n", ptr == _ptr);  // Fixed: __ptr -> _ptr and %u -> %d
    return 0;
}
// output
// 1870018264, 1870018260difference = 1
// comparison = 1



// 6:42:27+ par code
#include <stdio.h>

int main() {
    int age = 22;
    char _age = 'a';
    int *ptr = &age;
    char *_ptr = &_age;

    printf("%u, %u\ndifference = %u\n",ptr,_ptr, ptr-_ptr);
    return 0;
}