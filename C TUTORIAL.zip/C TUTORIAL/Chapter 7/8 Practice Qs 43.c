// 7:01:06+ par code
// Practice Qs 42
// int arr[] = {1, 2, 3, 4, 5}
// For the given array, what will the following give?
// a. *(arr+2)
// b. *(arr+5)

#include <stdio.h>

int countOdd(int arr[], int n);

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    printf("%d \n", *(arr+2));  
    printf("%d \n", *(arr+5));  
    printf("Odd count: %d \n", countOdd(arr, 5));
    return 0;
}

int countOdd(int arr[], int n) {
    int count = 0;
    for(int i = 0; i < n; i++) {
        if(arr[i] % 2 != 0) {  // odd
            count++;
        }
    }
    return count;
}
// output
// 3
// 0