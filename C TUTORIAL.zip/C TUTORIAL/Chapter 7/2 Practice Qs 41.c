// 6:27:42+ par code
// Practice Qs 41
// Write a program to enter price of 3 items & print their final cost with gst.

#include <stdio.h>

int main() {
    float price[3];
    
    printf("Enter 3 prices : ");
    scanf("%f", &price[0]);
    scanf("%f", &price[1]);
    scanf("%f", &price[2]);

    printf("Total price 1 : %f\n", price[0] * 1.18);  // Including 18% tax
    printf("Total price 2 : %f\n", price[1] * 1.18);
    printf("Total price 3 : %f\n", price[2] * 1.18);
    
    return 0;
}
// output
// enter 3 prices : 100
// 200
// 300

// total price 1 : 188.000000
// total price 2 : 236.000000
// total price 3 : 354.000000



// 6:33:24+ par code
// initialise
#include <stdio.h>

int main() {
    float price[3] = {100.0, 200.0, 300.0};
    
    // printf("Enter 3 prices : ");
    // scanf("%f", &price[0]);
    // scanf("%f", &price[1]);
    // scanf("%f", &price[2]);

    printf("Total price 1 : %f\n", price[0] * 1.18);  // Including 18% tax
    printf("Total price 2 : %f\n", price[1] * 1.18);
    printf("Total price 3 : %f\n", price[2] * 1.18);
    
    return 0;
}
// output
// enter 3 prices : 100
// 200
// 300

// total price 1 : 188.000000
// total price 2 : 236.000000
// total price 3 : 354.000000

