// 7:15:49+ par code
// Practice Qs 46
// Create a 2D array, storing the tables of 2 aaaaaaaaaa7 3.

#include <stdio.h>

void storeTable(int arr[][10], int n, int m, int number);

int main(){
    int tables[2][10];
    storeTable(tables, 0, 10, 2); // Stores 2's table
    storeTable(tables, 1, 10, 3); // Stores 3's table

    for (int i=0; i<10; i++){ // 0 to 10
        printf("%d\t", tables[0][i]);
    }

    printf("\n");
    for (int i=0; i<10; i++){ // 0 to 10
        printf("%d\t", tables[1][i]);
    }
    printf("\n");
    return 0;
}

void storeTable(int arr[][10], int n, int m, int number){
    for (int i = 0; i < m; i++)
    {                                 // 0 to 10
        arr[n][i] = number * (i + 1); // 2, 4, 6, 8, 10....
        // arr[1] [0] arr[1] [1] arr[1] [2] arr[0] [3] ...
    }
}
// output
// 2	4	6	8	10	12	14	16	18	20	
// 3	6	9	12	15	18	21	24	27	30