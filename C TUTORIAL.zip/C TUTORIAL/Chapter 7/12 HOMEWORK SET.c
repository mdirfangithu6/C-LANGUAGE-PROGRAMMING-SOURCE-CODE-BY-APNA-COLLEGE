// 7:22:15+ 
// HOMEWORK SET

// a. In an array of numbers, find how many times does a number 'x' occurs.
// b. Write a program to print the largest number in an array.
// c. Write a program to insert an element at the end of an array.


// a. In an array of numbers, find how many times does a number 'x' occurs.
// by chatGPT
#include <stdio.h>

int main() {
    int arr[100], n, x, count = 0;

    printf("Enter number of elements in array: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the number to count (x): ");
    scanf("%d", &x);

    for (int i = 0; i < n; i++) {
        if (arr[i] == x)
            count++;
    }

    printf("Number %d occurs %d times in the array.\n", x, count);

    return 0;
}



// b. Write a program to print the largest number in an array.
// by chatGPT
#include <stdio.h>

int main() {
    int arr[100], n, max;

    printf("Enter number of elements in array: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    max = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > max)
            max = arr[i];
    }

    printf("The largest number in the array is: %d\n", max);

    return 0;
}



// c. Write a program to insert an element at the end of an array.
// by chatGPT
#include <stdio.h>

int main() {
    int arr[100], n, element;

    printf("Enter number of elements in array: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the element to insert at the end: ");
    scanf("%d", &element);

    arr[n] = element;
    n++; // Increase size of array

    printf("Updated array:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}
