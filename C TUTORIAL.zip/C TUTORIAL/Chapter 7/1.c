// 6:20:20+ par code
#include <stdio.h>

int main(){
    int marks1 = 97 int marks2 = 98;
    int marks3 = 89;

    int marks[] = {97, 98, 89};
    return 0;
}

// 6:24:48+ par code
#include <stdio.h>

int main(){
    int marks[3];
    printf("Enter Physics marks : ");
    scanf("%d", &marks[0]);
    printf("Enter Chemistry marks : ");
    scanf("%d", &marks[1]);
    printf("Enter Math marks : ");
    scanf("%d", &marks[2]);
    printf("Physics = %d  Chemistry = %d  Math = %d \n", marks[0], marks[1], marks[2]);
    return 0;
}
// output
// Enter Physics marks : 97
// Enter Chemistry marks : 98
// Enter Math marks : 89

// Physics = 97, Chemistry = 98, Math = 89