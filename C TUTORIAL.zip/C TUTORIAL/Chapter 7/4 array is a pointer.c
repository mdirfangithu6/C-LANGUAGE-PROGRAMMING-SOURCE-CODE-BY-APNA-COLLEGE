// 6:43:10+ or 6:46:30+ par code
#include <stdio.h>

int main() {
    int aadhar[5];

    //input
    int *ptr = &aadhar[0];
    for(int i=0; i<5; i++) {
        printf("%d index : ", i);
        scanf("%d", (ptr+i));
    }

    //output
    for(int i=0; i<5; i++) {
        printf("%d index = %d\n", i, *(ptr+i));
    }
    return 0;
}
// output
// 0 index: 12
// 1 index: 13
// 2 index: 14
// 3 index: 15
// 4 index: 16

// 0 index: 12
// 1 index: 13
// 2 index: 14
// 3 index: 15
// 4 index: 16


// 6:48:54+ par code
#include <stdio.h>

int main() {
    int aadhar[5];

    //input
    int *ptr = &aadhar[0];
    for(int i=0; i<5; i++) {
        printf("%d index : ", i);
        scanf("%d", &aadhar[i]);
    }

    //output
    for(int i=0; i<5; i++) {
        printf("%d index = %d\n", i, aadhar[i]);
    }
    return 0;
}
// output
// 0 index: 12
// 1 index: 13
// 2 index: 14
// 3 index: 15
// 4 index: 16

// 0 index: 12
// 1 index: 13
// 2 index: 14
// 3 index: 15
// 4 index: 16